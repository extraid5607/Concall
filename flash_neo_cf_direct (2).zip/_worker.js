/**
 * Flash Neo — Cloudflare Pages Functions Backend (Kotak Neo Trade API v2)
 * Stateless Edge Router: Receives Kotak Neo session headers from the authenticated
 * browser session (stored in browser sessionStorage) and proxies live API calls
 * to Kotak Neo Trade API v2 with zero simulated data.
 */

const AUTH_BASE_PROD = "https://mis.kotaksecurities.com";
const AUTH_BASE_UAT = "https://uat.kotaksecurities.com";

const INDEX_CONFIG = {
  NIFTY:      { name: "Nifty 50",            fo: "nse_fo", spot: "nse_cm|Nifty 50",          lot: 65 },
  SENSEX:     { name: "BSE Sensex",          fo: "bse_fo", spot: "bse_cm|SENSEX",            lot: 20 },
  BANKNIFTY:  { name: "Nifty Bank",          fo: "nse_fo", spot: "nse_cm|Nifty Bank",        lot: 30 },
  FINNIFTY:   { name: "Nifty Fin Service",   fo: "nse_fo", spot: "nse_cm|Nifty Fin Service", lot: 60 },
  MIDCPNIFTY: { name: "Nifty Midcap Select", fo: "nse_fo", spot: "nse_cm|NIFTY MID SELECT",  lot: 120 },
  BANKEX:     { name: "BSE Bankex",          fo: "bse_fo", spot: "bse_cm|BANKEX",            lot: 30 },
};

const MCX_CONFIG = {
  GOLD:       { name: "MCX Gold",            fo: "mcx_fo", lot: 1 },
  GOLDM:      { name: "MCX Gold Mini",       fo: "mcx_fo", lot: 1 },
  SILVER:     { name: "MCX Silver",          fo: "mcx_fo", lot: 1 },
  SILVERM:    { name: "MCX Silver Mini",     fo: "mcx_fo", lot: 1 },
  CRUDEOIL:   { name: "MCX Crude Oil",       fo: "mcx_fo", lot: 1 },
  CRUDEOILM:  { name: "MCX Crude Oil Mini",  fo: "mcx_fo", lot: 1 },
  NATURALGAS: { name: "MCX Natural Gas",     fo: "mcx_fo", lot: 1 },
  NATGASMINI: { name: "MCX NatGas Mini",     fo: "mcx_fo", lot: 1 },
};

// Edge-isolate in-memory cache for Kotak Scrip Master CSVs (1 hour TTL)
const scripCache = new Map();

function jsonRes(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Cache-Control": "no-store",
    },
  });
}

function safeFloat(v, def = 0) {
  const n = parseFloat(String(v ?? "").replace(/,/g, "").trim());
  return Number.isFinite(n) ? n : def;
}

function normalizeMobile(mobile) {
  let m = String(mobile || "").trim().replace(/\s+/g, "");
  if (!m.startsWith("+")) {
    m = /^\d{10}$/.test(m) ? `+91${m}` : `+${m}`;
  }
  return m;
}

function resolveRoute(rawInput, ipVersion, defaultRelayUrl, relaySecret) {
  const cleaned = String(rawInput || "").trim();
  const ver = String(ipVersion || "auto").trim().toLowerCase();
  const safeVer = ["auto", "ipv4", "ipv6"].includes(ver) ? ver : "auto";

  if (!cleaned) {
    return {
      relayUrl: defaultRelayUrl || "",
      proxyUrl: "",
      ipVersion: safeVer,
      relaySecret: relaySecret || "",
    };
  }

  // Direct HTTPS relay override (e.g. https://my-relay.onrender.com with no @ or port)
  const isDirectHttpsRelay =
    /^https:\/\/[^/@:\s]+(\/.*)?$/i.test(cleaned);

  if (isDirectHttpsRelay) {
    return {
      relayUrl: cleaned.replace(/\/+$/, ""),
      proxyUrl: "",
      ipVersion: safeVer,
      relaySecret: relaySecret || "",
    };
  }

  // Otherwise treat as a per-user StaticIP.in proxy (http://user:pass@ip:port, socks5://..., or ip:port)
  const normalizedProxy = cleaned.includes("://") ? cleaned : `http://${cleaned}`;
  if (!defaultRelayUrl) {
    throw {
      status: 400,
      message:
        "Relay server not configured yet. Add RELAY_URL (your Render relay URL) in Cloudflare Pages -> Settings -> Environment Variables and redeploy.",
    };
  }

  return {
    relayUrl: defaultRelayUrl,
    proxyUrl: normalizedProxy,
    ipVersion: safeVer,
    relaySecret: relaySecret || "",
  };
}

function getSession(request, env) {
  const token = request.headers.get("X-Neo-Token") || "";
  const sid = request.headers.get("X-Neo-Sid") || "";
  const baseUrl = (request.headers.get("X-Neo-Base") || "").replace(/\/+$/, "");
  const consumerKey = request.headers.get("X-Neo-Key") || "";
  const defaultRelayUrl = String(env?.RELAY_URL || "").trim().replace(/\/+$/, "");
  const relaySecret = String(env?.RELAY_SECRET || "").trim();
  const customRelay = (request.headers.get("X-Neo-Relay") || "").trim().replace(/\/+$/, "");
  const proxyUrl = (request.headers.get("X-Neo-Proxy") || "").trim();
  const ipVersion = (request.headers.get("X-Neo-IP-Version") || "auto").trim().toLowerCase();

  let route;
  if (proxyUrl) {
    route = resolveRoute(proxyUrl, ipVersion, customRelay || defaultRelayUrl, relaySecret);
  } else {
    route = {
      relayUrl: customRelay || defaultRelayUrl,
      proxyUrl: "",
      ipVersion: ["auto", "ipv4", "ipv6"].includes(ipVersion) ? ipVersion : "auto",
      relaySecret,
    };
  }
  return { token, sid, baseUrl, consumerKey, relayUrl: route.relayUrl, route };
}

function requireSession(session) {
  if (!session.token || !session.sid || !session.baseUrl || !session.consumerKey) {
    throw { status: 401, message: "Kotak Neo session not linked. Connect in Account tab first." };
  }
}

function tradeHeaders(session) {
  return {
    accept: "application/json",
    Auth: session.token,
    Sid: session.sid,
    "neo-fin-key": "neotradeapi",
    "Content-Type": "application/x-www-form-urlencoded",
  };
}

function quoteHeaders(session) {
  return {
    Authorization: session.consumerKey,
    "Content-Type": "application/json",
    accept: "application/json",
  };
}

/**
 * Optional HTTPS Static-IP Relay support:
 * If the user configures an HTTPS relay URL (e.g. https://relay.yourdomain.com),
 * outbound requests pass target URL in X-Target-URL header so the relay exits
 * from their whitelisted static IPv4/IPv6 address.
 */
async function kotakFetch(targetUrl, options = {}, routeOrRelay = "") {
  const route =
    typeof routeOrRelay === "string"
      ? { relayUrl: routeOrRelay, proxyUrl: "", ipVersion: "auto", relaySecret: "" }
      : routeOrRelay || {};

  if (route.relayUrl) {
    const headers = new Headers(options.headers || {});
    headers.set("X-Target-URL", targetUrl);
    if (route.proxyUrl) headers.set("X-Upstream-Proxy", route.proxyUrl);
    if (route.ipVersion && route.ipVersion !== "auto") headers.set("X-IP-Version", route.ipVersion);
    if (route.relaySecret) headers.set("X-Relay-Secret", route.relaySecret);
    return fetch(route.relayUrl, { ...options, headers });
  }
  return fetch(targetUrl, options);
}

function parseCsvLine(line) {
  const out = [];
  let cur = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      inQuotes = !inQuotes;
    } else if (ch === "," && !inQuotes) {
      out.push(cur);
      cur = "";
    } else {
      cur += ch;
    }
  }
  out.push(cur);
  return out;
}

function parseExpiry(rawVal) {
  const val = String(rawVal || "").trim();
  if (!val) return null;
  if (/^\d+$/.test(val)) {
    let ts = parseInt(val, 10);
    if (ts < 1600000000) ts += 315513000; // NSE 1980-epoch adjustment
    const d = new Date(ts * 1000);
    if (!Number.isNaN(d.getTime())) return d.toISOString().slice(0, 10);
  }
  const parsed = Date.parse(val);
  if (!Number.isNaN(parsed)) return new Date(parsed).toISOString().slice(0, 10);
  return val;
}

const csvUrlCache = new Map();
const symbolListCache = { ts: 0, stocks: [] };

async function getScripCsvText(session, segment) {
  const segKey = segment.toLowerCase();
  let csvUrl = null;
  const cachedUrl = csvUrlCache.get(segKey);
  if (cachedUrl && Date.now() - cachedUrl.ts < 3600_000) {
    csvUrl = cachedUrl.url;
  } else {
    const r = await kotakFetch(
      `${session.baseUrl}/script-details/1.0/masterscrip/file-paths`,
      { headers: quoteHeaders(session) },
      session.route
    );
    if (!r.ok) throw { status: 502, message: `Scrip Master paths failed (${r.status}).` };
    const payload = await r.json();
    const files = payload?.data?.filesPaths || payload?.filesPaths || [];
    for (const u of files) {
      const s = String(u).toLowerCase();
      if (s.includes("nse_fo")) csvUrlCache.set("nse_fo", { ts: Date.now(), url: u });
      if (s.includes("bse_fo")) csvUrlCache.set("bse_fo", { ts: Date.now(), url: u });
      if (s.includes("mcx_fo")) csvUrlCache.set("mcx_fo", { ts: Date.now(), url: u });
      if (s.includes(segKey)) csvUrl = u;
    }
    if (!csvUrl) throw { status: 404, message: `No Scrip Master CSV found for ${segment}.` };
  }

  const csvResp = await fetch(csvUrl, { cf: { cacheTtl: 3600, cacheEverything: true } });
  if (!csvResp.ok) throw { status: 502, message: `Failed downloading Scrip Master CSV (${csvResp.status}).` };
  return await csvResp.text();
}

function getCsvColumnIndexes(headerLine) {
  const headers = headerLine.replace(/\r$/, "").split(",").map((h) => h.trim().replace(/^"|"$/g, ""));
  return {
    pSymbolName: headers.indexOf("pSymbolName"),
    pTrdSymbol: headers.indexOf("pTrdSymbol"),
    pOptionType: headers.indexOf("pOptionType"),
    lExpiryDate: headers.indexOf("lExpiryDate"),
    pExpiryDate: headers.indexOf("pExpiryDate"),
    dStrikePrice: headers.findIndex((h) => h.startsWith("dStrikePrice")),
    pSymbol: headers.indexOf("pSymbol"),
    lLotSize: headers.indexOf("lLotSize"),
  };
}

function fastCleanCell(val) {
  if (!val) return "";
  const s = val.trim();
  return s.length >= 2 && s.charCodeAt(0) === 34 && s.charCodeAt(s.length - 1) === 34 ? s.slice(1, -1).trim() : s;
}

async function loadScripMasterForSymbol(session, segment, targetSym) {
  const sym = String(targetSym || "").toUpperCase().trim();
  const cacheKey = `${segment.toLowerCase()}:${sym}`;
  const cached = scripCache.get(cacheKey);
  if (cached && Date.now() - cached.ts < 3600_000) return cached.rows;

  const text = await getScripCsvText(session, segment);
  const firstNl = text.indexOf("\n");
  if (firstNl < 0) return [];
  const idx = getCsvColumnIndexes(text.slice(0, firstNl));
  const isMcx = segment.toLowerCase() === "mcx_fo";
  const rows = [];
  const len = text.length;
  const parseLine = (line) => {
    const cols = line.split(",");
    const symName = fastCleanCell(cols[idx.pSymbolName]).toUpperCase();
    if (symName !== sym) return;
    const optType = fastCleanCell(cols[idx.pOptionType]).toUpperCase();
    const isOpt = optType === "CE" || optType === "PE";
    const isFut = isMcx && (!optType || optType === "XX" || optType === "FUT");
    if (!isOpt && !isFut) return;
    rows.push({
      pSymbolName: symName,
      pTrdSymbol: fastCleanCell(cols[idx.pTrdSymbol]),
      pOptionType: isOpt ? optType : "FUT",
      rawExpiry: fastCleanCell(cols[idx.lExpiryDate]) || fastCleanCell(cols[idx.pExpiryDate]) || "",
      rawStrike: fastCleanCell(cols[idx.dStrikePrice]) || "0",
      pSymbol: fastCleanCell(cols[idx.pSymbol]),
      lLotSize: fastCleanCell(cols[idx.lLotSize]) || "0",
    });
  };

  // SIMD-fast jump straight to matching symbol rows (<4ms on 80k+ rows)
  const scanNeedle = (needle) => {
    let searchFrom = firstNl + 1;
    while (searchFrom < len) {
      const hit = text.indexOf(needle, searchFrom);
      if (hit === -1) break;
      const lineStart = text.lastIndexOf("\n", hit) + 1;
      let lineEnd = text.indexOf("\n", hit);
      if (lineEnd === -1) lineEnd = len;
      searchFrom = lineEnd + 1;
      parseLine(text.slice(lineStart, lineEnd));
    }
  };

  scanNeedle(`,${sym},`);
  if (rows.length === 0) scanNeedle(`,"${sym}",`);
  if (rows.length === 0) scanNeedle(sym);

  scripCache.set(cacheKey, { ts: Date.now(), rows });
  return rows;
}

async function loadFoStockSymbols(session) {
  if (symbolListCache.stocks.length > 0 && Date.now() - symbolListCache.ts < 3600_000) {
    return symbolListCache.stocks;
  }
  const text = await getScripCsvText(session, "nse_fo");
  const firstNl = text.indexOf("\n");
  if (firstNl < 0) return [];
  const idx = getCsvColumnIndexes(text.slice(0, firstNl));
  const symCol = idx.pSymbolName;
  if (symCol < 0) return [];

  const set = new Set();
  let pos = firstNl + 1;
  const len = text.length;
  while (pos < len) {
    let end = text.indexOf("\n", pos);
    if (end === -1) end = len;
    // Walk only up to symCol commas without allocating an array
    let cPos = pos;
    let col = 0;
    while (col < symCol && cPos < end) {
      const nextComma = text.indexOf(",", cPos);
      if (nextComma === -1 || nextComma >= end) { cPos = end; break; }
      cPos = nextComma + 1;
      col++;
    }
    if (col === symCol && cPos < end) {
      const nextComma = text.indexOf(",", cPos);
      const cellEnd = nextComma === -1 || nextComma > end ? end : nextComma;
      const name = fastCleanCell(text.slice(cPos, cellEnd)).toUpperCase();
      if (name && !INDEX_CONFIG[name]) set.add(name);
    }
    pos = end + 1;
  }

  const stocks = Array.from(set).sort();
  symbolListCache.ts = Date.now();
  symbolListCache.stocks = stocks;
  return stocks;
}

async function fetchQuoteBatch(session, batch) {
  const joined = batch.map((q) => encodeURIComponent(q).replace(/%7C/g, "|")).join(",");
  const url = `${session.baseUrl}/script-details/1.0/quotes/neosymbol/${joined}/all`;
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const r = await kotakFetch(url, { headers: quoteHeaders(session) }, session.route);
      if (r.ok) {
        const data = await r.json();
        if (Array.isArray(data)) return data;
        if (Array.isArray(data?.data)) return data.data;
      }
    } catch {}
  }
  return [];
}

async function fetchQuotes(session, queries) {
  const unique = Array.from(new Set((queries || []).filter(Boolean)));
  const batches = [];
  const BATCH_SIZE = 25;
  for (let i = 0; i < unique.length; i += BATCH_SIZE) {
    batches.push(unique.slice(i, i + BATCH_SIZE));
  }
  const results = [];
  const CONCURRENCY = 4;
  for (let i = 0; i < batches.length; i += CONCURRENCY) {
    const chunk = batches.slice(i, i + CONCURRENCY);
    const settled = await Promise.all(chunk.map((b) => fetchQuoteBatch(session, b)));
    for (const arr of settled) {
      if (arr && arr.length) results.push(...arr);
    }
  }
  return results;
}

async function handleApiRequest(request, subPath, env) {
  const url = new URL(request.url);
  const method = request.method.toUpperCase();
  const defaultRelayUrl = String(env?.RELAY_URL || "").trim().replace(/\/+$/, "");
    const relaySecret = String(env?.RELAY_SECRET || "").trim();
    const session = getSession(request, env);

  try {
    // 0. GET /api/relay/wakeup — Wakes up sleeping Render free-tier relay cleanly
    if (subPath === "relay/wakeup" && method === "GET") {
      if (!defaultRelayUrl) {
        return jsonRes({ awake: true, relay_configured: false, status: 200 });
      }
      try {
        const r = await fetch(`${defaultRelayUrl}/health`, {
          method: "GET",
          headers: {
            "User-Agent": "Mozilla/5.0 FlashNeo-Wakeup/1.0",
            accept: "application/json",
          },
        });
        const ok = r.ok;
        let data = null;
        if (ok) data = await r.json().catch(() => null);
        return jsonRes({
          awake: ok && Boolean(data && data.status === "ok"),
          relay_configured: true,
          relay_url: defaultRelayUrl,
          status: r.status,
          relay: data,
        });
      } catch (e) {
        return jsonRes({
          awake: false,
          relay_configured: true,
          relay_url: defaultRelayUrl,
          status: 503,
          error: String(e?.message || e),
        });
      }
    }

    // 1. POST /api/auth/login
    if (subPath === "auth/login" && method === "POST") {
      const body = await request.json();
      const consumerKey = String(body.consumer_key || "").trim();
      const mobile = normalizeMobile(body.mobile_number);
      const ucc = String(body.ucc || "").trim().toUpperCase();
      const totp = String(body.totp || "").trim();
      const mpin = String(body.mpin || "").trim();
      const env = String(body.environment || "prod").toLowerCase();
      const loginRoute = resolveRoute(body.proxy_url, body.ip_version, defaultRelayUrl, relaySecret);

      if (!consumerKey || !ucc || !/^\d{6}$/.test(totp) || !/^\d{6}$/.test(mpin)) {
        return jsonRes({ detail: "Consumer Key, UCC, 6-digit TOTP, and 6-digit MPIN are required." }, 400);
      }

      const authBase = env === "uat" ? AUTH_BASE_UAT : AUTH_BASE_PROD;

      // Step 1: TOTP Login
      const r1 = await kotakFetch(
        `${authBase}/login/1.0/tradeApiLogin`,
        {
          method: "POST",
          headers: {
            Authorization: consumerKey,
            "neo-fin-key": "neotradeapi",
            "Content-Type": "application/json",
            accept: "application/json",
          },
          body: JSON.stringify({ mobileNumber: mobile, ucc, totp }),
        },
        loginRoute
      );
      const d1 = await r1.json().catch(() => ({}));
      const data1 = d1.data || d1;
      if (r1.status === 502 || r1.status === 503 || r1.status === 504) {
        return jsonRes({ detail: `Render relay is waking up (${r1.status}). Wait ~30s and retry, or tap Render Site.` }, 502);
      }
      if (!r1.ok || !data1.token || !data1.sid) {
        return jsonRes({ detail: `Kotak TOTP Login failed: ${d1.error || d1.message || data1.message || r1.status}` }, 401);
      }

      // Step 2: MPIN Validate
      const r2 = await kotakFetch(
        `${authBase}/login/1.0/tradeApiValidate`,
        {
          method: "POST",
          headers: {
            Authorization: consumerKey,
            "neo-fin-key": "neotradeapi",
            sid: data1.sid,
            Auth: data1.token,
            "Content-Type": "application/json",
            accept: "application/json",
          },
          body: JSON.stringify({ mpin }),
        },
        loginRoute
      );
      const d2 = await r2.json().catch(() => ({}));
      const data2 = d2.data || d2;
      if (r2.status === 502 || r2.status === 503 || r2.status === 504) {
        return jsonRes({ detail: `Render relay is waking up (${r2.status}). Wait ~30s and retry, or tap Render Site.` }, 502);
      }
      if (!r2.ok || !data2.token || !data2.sid) {
        return jsonRes({ detail: `Kotak MPIN Validation failed: ${d2.error || d2.message || data2.message || r2.status}` }, 401);
      }

      return jsonRes({
        connected: true,
        ucc,
        environment: env,
        trading_token: data2.token,
        trading_sid: data2.sid,
        base_url: String(data2.baseUrl || authBase).replace(/\/+$/, ""),
        consumer_key: consumerKey,
        relay_url: loginRoute.proxyUrl ? "" : (loginRoute.relayUrl === defaultRelayUrl ? "" : loginRoute.relayUrl),
        proxy_url: loginRoute.proxyUrl || "",
        ip_version: loginRoute.ipVersion || "auto",
      });
    }

    // 2. POST /api/network/check-ip
    if (subPath === "network/check-ip" && method === "POST") {
      const body = await request.json().catch(() => ({}));
      const checkRoute = resolveRoute(body.proxy_url, body.ip_version, defaultRelayUrl, relaySecret);
      let ipv4 = null;
      let ipv6 = null;
      try {
        const r4 = await kotakFetch("https://api4.ipify.org?format=json", {}, checkRoute);
        if (r4.ok) ipv4 = (await r4.json()).ip;
      } catch {}
      try {
        const r6 = await kotakFetch("https://api6.ipify.org?format=json", {}, checkRoute);
        if (r6.ok) ipv6 = (await r6.json()).ip;
      } catch {}
      return jsonRes({
        ipv4,
        ipv6,
        via_relay: Boolean(checkRoute.relayUrl),
        via_proxy: Boolean(checkRoute.proxyUrl),
        relay_configured: Boolean(defaultRelayUrl),
      });
    }

    // All routes below require an active Kotak Neo session
    requireSession(session);

    // 3. GET /api/option-chain/symbols
    if (subPath === "option-chain/symbols" && method === "GET") {
      const stocks = await loadFoStockSymbols(session);
      return jsonRes({ indices: Object.keys(INDEX_CONFIG), stocks });
    }

    // 4. GET /api/option-chain
    if (subPath === "option-chain" && method === "GET") {
      let sym = (url.searchParams.get("symbol") || "NIFTY").toUpperCase().trim();
      if (sym === "CRUDE") sym = "CRUDEOIL";
      if (sym === "CRUDEM") sym = "CRUDEOILM";
      const reqExpiry = url.searchParams.get("expiry") || "";
      const strikesCount = parseInt(url.searchParams.get("strikes") || "10", 10);

      const idxCfg = INDEX_CONFIG[sym];
      const mcxCfg = MCX_CONFIG[sym];
      const foSeg = idxCfg ? idxCfg.fo : mcxCfg ? "mcx_fo" : "nse_fo";
      const defaultLot = idxCfg ? idxCfg.lot : mcxCfg ? mcxCfg.lot : 1;

      const allRows = await loadScripMasterForSymbol(session, foSeg, sym);
      const todayIso = new Date().toISOString().slice(0, 10);
      const contracts = [];
      const mcxFutures = [];
      const expirySet = new Set();

      for (const row of allRows) {
        if (row.pSymbolName !== sym) continue;
        const expIso = parseExpiry(row.rawExpiry);
        if (!expIso || expIso < todayIso) continue;
        if (row.pOptionType === "FUT") {
          mcxFutures.push({ expiry: expIso, token: row.pSymbol });
          continue;
        }
        expirySet.add(expIso);
        const rawSt = safeFloat(row.rawStrike);
        const strike = rawSt > 1_000_000 ? rawSt / 100 : rawSt;
        contracts.push({
          expiry: expIso,
          strike,
          option_type: row.pOptionType,
          trading_symbol: row.pTrdSymbol,
          instrument_token: row.pSymbol,
          lot_size: Math.round(safeFloat(row.lLotSize, defaultLot)) || defaultLot,
          exchange_segment: foSeg,
        });
      }

      let spotQuery = idxCfg ? idxCfg.spot : `nse_cm|${sym}-EQ`;
      if (mcxCfg && mcxFutures.length > 0) {
        mcxFutures.sort((a, b) => a.expiry.localeCompare(b.expiry));
        spotQuery = `mcx_fo|${mcxFutures[0].token}`;
      }
      const spotQuotes = await fetchQuotes(session, [spotQuery]);
      const sq = spotQuotes[0] || {};
      const spotLtp = safeFloat(sq.ltp);
      const spotChg = safeFloat(sq.change);
      const spotPchg = safeFloat(sq.per_change);

      const expiries = Array.from(expirySet).sort();
      if (expiries.length === 0) {
        return jsonRes({ symbol: sym, spot_ltp: spotLtp, spot_change: spotChg, spot_per_change: spotPchg, lot_size: defaultLot, expiries: [], rows: [] });
      }

      const selectedExpiry = expiries.includes(reqExpiry) ? reqExpiry : expiries[0];
      const expContracts = contracts.filter((c) => c.expiry === selectedExpiry);
      const allStrikes = Array.from(new Set(expContracts.map((c) => c.strike))).sort((a, b) => a - b);

      let atmStrike = allStrikes[Math.floor(allStrikes.length / 2)] || 0;
      if (spotLtp > 0 && allStrikes.length > 0) {
        atmStrike = allStrikes.reduce((best, s) => (Math.abs(s - spotLtp) < Math.abs(best - spotLtp) ? s : best), allStrikes[0]);
      }
      const atmIdx = Math.max(0, allStrikes.indexOf(atmStrike));
      const visibleStrikes = strikesCount > 0
        ? allStrikes.slice(Math.max(0, atmIdx - strikesCount), Math.min(allStrikes.length, atmIdx + strikesCount + 1))
        : allStrikes;

      const visSet = new Set(visibleStrikes);
      const visContracts = expContracts.filter((c) => visSet.has(c.strike));
      const quoteQueries = visContracts.filter((c) => c.instrument_token).map((c) => `${c.exchange_segment}|${c.instrument_token}`);
      const rawQuotes = await fetchQuotes(session, quoteQueries);
      const qByTok = new Map(rawQuotes.map((q) => [String(q.exchange_token || ""), q]));

      const chainMap = new Map(visibleStrikes.map((s) => [s, { strike: s, is_atm: s === atmStrike, ce: null, pe: null }]));
      let totalCeOi = 0, totalPeOi = 0;

      for (const c of visContracts) {
        const q = qByTok.get(c.instrument_token) || {};
        const oi = safeFloat(q.open_int || q.oi);
        const leg = {
          trading_symbol: c.trading_symbol,
          instrument_token: c.instrument_token,
          exchange_segment: c.exchange_segment,
          lot_size: c.lot_size,
          ltp: safeFloat(q.ltp),
          oi,
          volume: safeFloat(q.last_volume || q.volume),
        };
        if (c.option_type === "CE") { chainMap.get(c.strike).ce = leg; totalCeOi += oi; }
        else { chainMap.get(c.strike).pe = leg; totalPeOi += oi; }
      }

      const chainRows = visibleStrikes.map((s) => chainMap.get(s));
      const pcr = totalCeOi > 0 ? Number((totalPeOi / totalCeOi).toFixed(2)) : null;

      let maxPain = null;
      if (totalCeOi > 0 || totalPeOi > 0) {
        let minPayout = Infinity;
        for (const cand of visibleStrikes) {
          let payout = 0;
          for (const row of chainRows) {
            if (row.ce && cand > row.strike) payout += (cand - row.strike) * row.ce.oi;
            if (row.pe && cand < row.strike) payout += (row.strike - cand) * row.pe.oi;
          }
          if (payout < minPayout) { minPayout = payout; maxPain = cand; }
        }
      }

      const atmRow = chainMap.get(atmStrike);
      const atmStraddle = atmRow?.ce && atmRow?.pe ? Number((atmRow.ce.ltp + atmRow.pe.ltp).toFixed(2)) : null;

      return jsonRes({
        symbol: sym,
        exchange_segment: foSeg,
        spot_ltp: spotLtp,
        spot_change: spotChg,
        spot_per_change: spotPchg,
        lot_size: visContracts[0]?.lot_size || defaultLot,
        expiries,
        selected_expiry: selectedExpiry,
        atm_strike: atmStrike,
        pcr,
        max_pain: maxPain,
        atm_straddle: atmStraddle,
        updated_at: new Date().toISOString(),
        rows: chainRows,
      });
    }

    // 5. GET /api/orders
    if (subPath === "orders" && method === "GET") {
      const r = await kotakFetch(`${session.baseUrl}/quick/user/orders`, { headers: tradeHeaders(session) }, session.route);
      const data = await r.json().catch(() => ({ data: [] }));
      return jsonRes({ orders: Array.isArray(data) ? data : (data.data || []) });
    }

    // 6. POST /api/orders/place
    if (subPath === "orders/place" && method === "POST") {
      const b = await request.json();
      const jData = {
        am: b.amo || "NO",
        dq: "0",
        es: b.exchange_segment,
        mp: "0",
        pc: b.product || "NRML",
        pf: "N",
        pr: b.order_type === "MKT" ? "0" : String(b.price || 0),
        pt: b.order_type || "MKT",
        qt: String(b.quantity),
        rt: b.validity || "DAY",
        tp: ["SL", "SL-M"].includes(b.order_type) ? String(b.trigger_price || 0) : "0",
        ts: b.trading_symbol,
        tt: b.transaction_type,
      };
      const form = new URLSearchParams({ jData: JSON.stringify(jData) });
      const r = await kotakFetch(
        `${session.baseUrl}/quick/order/rule/ms/place`,
        { method: "POST", headers: tradeHeaders(session), body: form.toString() },
        session.route
      );
      const res = await r.json().catch(() => ({}));
      if (!r.ok || res.stat === "Not_Ok") return jsonRes({ detail: res.emsg || JSON.stringify(res) }, 400);
      return jsonRes({ response: res });
    }

    // 7. POST /api/orders/modify
    if (subPath === "orders/modify" && method === "POST") {
      const b = await request.json();
      const jData = {
        no: b.order_id,
        es: b.exchange_segment,
        ts: b.trading_symbol,
        tt: b.transaction_type,
        pc: b.product || "NRML",
        pt: b.order_type || "L",
        qt: String(b.quantity),
        pr: b.order_type === "MKT" ? "0" : String(b.price || 0),
        tp: ["SL", "SL-M"].includes(b.order_type) ? String(b.trigger_price || 0) : "0",
        dq: "0",
        vd: b.validity || "DAY",
        mp: "0",
        dd: "NA",
      };
      if (b.token) jData.tk = b.token;
      const form = new URLSearchParams({ jData: JSON.stringify(jData) });
      const r = await kotakFetch(
        `${session.baseUrl}/quick/order/vr/modify`,
        { method: "POST", headers: tradeHeaders(session), body: form.toString() },
        session.route
      );
      const res = await r.json().catch(() => ({}));
      if (!r.ok || res.stat === "Not_Ok") return jsonRes({ detail: res.emsg || JSON.stringify(res) }, 400);
      return jsonRes({ response: res });
    }

    // 8. POST /api/orders/cancel
    if (subPath === "orders/cancel" && method === "POST") {
      const b = await request.json();
      const jData = { on: b.order_id, am: b.amo || "NO" };
      const form = new URLSearchParams({ jData: JSON.stringify(jData) });
      const r = await kotakFetch(
        `${session.baseUrl}/quick/order/cancel`,
        { method: "POST", headers: tradeHeaders(session), body: form.toString() },
        session.route
      );
      const res = await r.json().catch(() => ({}));
      if (!r.ok || res.stat === "Not_Ok") return jsonRes({ detail: res.emsg || JSON.stringify(res) }, 400);
      return jsonRes({ response: res });
    }

    // 9. GET /api/positions
    if (subPath === "positions" && method === "GET") {
      let r = await kotakFetch(`${session.baseUrl}/portfolio/v2/positions`, { headers: tradeHeaders(session) }, session.route);
      if (!r.ok) {
        r = await kotakFetch(`${session.baseUrl}/quick/user/positions`, { headers: tradeHeaders(session) }, session.route);
      }
      const data = await r.json().catch(() => ({ data: [] }));
      return jsonRes({ positions: Array.isArray(data) ? data : (data.data || []) });
    }

    // 10. POST /api/positions/exit
    if (subPath === "positions/exit" && method === "POST") {
      const b = await request.json();
      const netQty = parseInt(b.net_qty, 10);
      if (!netQty) return jsonRes({ detail: "Position already flat." }, 400);
      const jData = {
        am: "NO", dq: "0", es: b.exchange_segment || "nse_fo", mp: "0",
        pc: b.product || "NRML", pf: "N", pr: "0", pt: "MKT",
        qt: String(Math.abs(netQty)), rt: "DAY", tp: "0",
        ts: b.trading_symbol, tt: netQty > 0 ? "S" : "B",
      };
      const form = new URLSearchParams({ jData: JSON.stringify(jData) });
      const r = await kotakFetch(
        `${session.baseUrl}/quick/order/rule/ms/place`,
        { method: "POST", headers: tradeHeaders(session), body: form.toString() },
        session.route
      );
      const res = await r.json().catch(() => ({}));
      if (!r.ok || res.stat === "Not_Ok") return jsonRes({ detail: res.emsg || JSON.stringify(res) }, 400);
      return jsonRes({ response: res });
    }

    // 11. POST /api/positions/exit-all
    if (subPath === "positions/exit-all" && method === "POST") {
      let r = await kotakFetch(`${session.baseUrl}/portfolio/v2/positions`, { headers: tradeHeaders(session) }, session.route);
      if (!r.ok) r = await kotakFetch(`${session.baseUrl}/quick/user/positions`, { headers: tradeHeaders(session) }, session.route);
      const data = await r.json().catch(() => ({ data: [] }));
      const list = Array.isArray(data) ? data : (data.data || []);
      let exited = 0;
      for (const p of list) {
        const net = (parseInt(p.flBuyQty || 0, 10) + parseInt(p.cfBuyQty || 0, 10)) - (parseInt(p.flSellQty || 0, 10) + parseInt(p.cfSellQty || 0, 10));
        if (!net) continue;
        const jData = {
          am: "NO", dq: "0", es: p.exSeg || "nse_fo", mp: "0",
          pc: p.prod || "NRML", pf: "N", pr: "0", pt: "MKT",
          qt: String(Math.abs(net)), rt: "DAY", tp: "0",
          ts: p.trdSym, tt: net > 0 ? "S" : "B",
        };
        const form = new URLSearchParams({ jData: JSON.stringify(jData) });
        await kotakFetch(`${session.baseUrl}/quick/order/rule/ms/place`, { method: "POST", headers: tradeHeaders(session), body: form.toString() }, session.route);
        exited++;
      }
      return jsonRes({ exited_count: exited });
    }

    // 12. GET /api/account
    if (subPath === "account" && method === "GET") {
      const form = new URLSearchParams({ jData: JSON.stringify({ seg: "ALL", exch: "ALL", prod: "ALL" }) });
      const rLim = await kotakFetch(
        `${session.baseUrl}/quick/user/limits`,
        { method: "POST", headers: tradeHeaders(session), body: form.toString() },
        session.route
      );
      const limits = await rLim.json().catch(() => ({}));
      return jsonRes({ limits });
    }

    return jsonRes({ detail: `Unknown endpoint: /api/${subPath}` }, 404);
  } catch (err) {
    return jsonRes({ detail: err?.message || String(err) }, err?.status || 500);
  }
}


export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    if (url.pathname.startsWith("/api/")) {
      if (request.method === "OPTIONS") {
        return new Response(null, {
          status: 204,
          headers: {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type, X-Neo-Token, X-Neo-Sid, X-Neo-Base, X-Neo-Key, X-Neo-Relay, X-Neo-Proxy, X-Neo-IP-Version",
          },
        });
      }
      const subPath = url.pathname.replace(/^\/api\//, "").replace(/\/+$/, "");
      return handleApiRequest(request, subPath, env);
    }
    return env.ASSETS.fetch(request);
  },
};
