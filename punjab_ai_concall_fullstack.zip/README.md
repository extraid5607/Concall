# Concall ਪੰਜਾਬੀ — Punjab AI

Full-stack web app that connects to NSE/BSE earnings call filings, extracts Concall PDFs, translates them into Gurmukhi Punjabi while keeping common English financial terms intact, generates summaries & Q&A highlights, and reads them aloud in Punjabi.

## 1. Deploy Backend Relay on Render (Free Tier)
1. Push this repo (or the `backend/` folder) to GitHub.
2. Create a **New Web Service** on Render.com (or use `render.yaml`).
3. Build command: `pip install -r requirements.txt`
4. Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
5. Copy your live Render URL (e.g. `https://punjab-ai-concall-relay.onrender.com`).

## 2. Deploy Frontend on Cloudflare Pages (Direct Upload)
1. Open Cloudflare Dashboard → Workers & Pages → Create → Pages → **Upload assets**.
2. Upload the `frontend/` folder (`index.html` + `manifest.json`).
3. Open your live site, tap the **Settings (gear)** icon, paste your Render Relay URL, and click **Test & Save**.

## 3. Optional AI Upgrade
- Free glossary-protected Punjabi translation works out of the box with zero API keys.
- To enable Gemini AI natural Punjabi translation + executive sentiment & summary, paste a free Gemini API key in Settings.
